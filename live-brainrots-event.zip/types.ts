
export interface BrainrotItem {
  id: string;
  name: string;
  rarity: 'RADIOACTIVE' | 'SECRET' | 'LEGENDARY';
  image: string;
}

export interface RobloxUser {
  username: string;
  displayName: string;
  userId: string;
  avatarUrl: string;
  joinedDate: string;
  friends: number;
  followers: number;
  following: number;
}

export interface LiveActivity {
  id: string;
  username: string;
  items: string[];
  timestamp: number;
  avatarUrl: string;
}

export enum ClaimStep {
  IDLE,
  VALIDATING,
  ENCRYPTING,
  AWAITING_VERIFICATION,
  FINALIZING,
  READY
}
