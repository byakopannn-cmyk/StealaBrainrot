
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import AuthSection from './components/AuthSection';
import RewardSelection from './components/RewardSelection';
import LiveActivityFeed from './components/LiveActivity';
import ClaimModal from './components/ClaimModal';
import { RobloxUser, BrainrotItem, ClaimStep } from './types';

const App: React.FC = () => {
  const [authenticatedUser, setAuthenticatedUser] = useState<RobloxUser | null>(null);
  const [selectedItems, setSelectedItems] = useState<BrainrotItem[]>([]);
  const [isClaimModalOpen, setIsClaimModalOpen] = useState(false);
  const [claimStep, setClaimStep] = useState<ClaimStep>(ClaimStep.IDLE);
  const [showLimitToast, setShowLimitToast] = useState(false);

  const handleVerify = useCallback((user: RobloxUser) => {
    setAuthenticatedUser(user);
  }, []);

  const handleSelectItem = (item: BrainrotItem) => {
    if (selectedItems.find(i => i.id === item.id)) {
      setSelectedItems(prev => prev.filter(i => i.id !== item.id));
      return;
    }

    if (selectedItems.length >= 3) {
      setShowLimitToast(true);
      setTimeout(() => setShowLimitToast(false), 3000);
      return;
    }

    setSelectedItems(prev => [...prev, item]);
  };

  const handleClearSelection = () => {
    setSelectedItems([]);
  };

  const handleStartClaim = () => {
    if (selectedItems.length === 0) return;
    setIsClaimModalOpen(true);
    startClaimProcess();
  };

  const startClaimProcess = () => {
    setClaimStep(ClaimStep.VALIDATING);
    
    setTimeout(() => {
      setClaimStep(ClaimStep.ENCRYPTING);
    }, 2000);

    setTimeout(() => {
      setClaimStep(ClaimStep.AWAITING_VERIFICATION);
    }, 4500);
  };

  const handleCompleteTransfer = () => {
    setClaimStep(ClaimStep.FINALIZING);
    setTimeout(() => {
      setClaimStep(ClaimStep.READY);
    }, 2000);
  };

  return (
    <div className="min-h-screen pb-20 max-w-4xl mx-auto px-4 sm:px-6">
      <Header />
      
      <main className="space-y-8 mt-8">
        <AuthSection 
          onVerify={handleVerify} 
          authenticatedUser={authenticatedUser}
          onReset={() => setAuthenticatedUser(null)}
        />

        <div className={authenticatedUser ? "opacity-100 transition-opacity duration-500" : "opacity-40 pointer-events-none"}>
          <RewardSelection 
            selectedItems={selectedItems}
            onSelectItem={handleSelectItem}
            onClearSelection={handleClearSelection}
            onClaim={handleStartClaim}
            isAuth={!!authenticatedUser}
          />
        </div>

        <LiveActivityFeed />
      </main>

      {/* Notifications */}
      {showLimitToast && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-red-500/90 text-white px-6 py-3 rounded-lg shadow-xl flex items-center gap-3 animate-bounce z-50">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <span className="font-bold">Limit Reached!</span>
          <span>Max 3 items allowed.</span>
        </div>
      )}

      {/* Claim Modal */}
      {isClaimModalOpen && (
        <ClaimModal 
          step={claimStep}
          user={authenticatedUser}
          items={selectedItems}
          onClose={() => {
            setIsClaimModalOpen(false);
            setClaimStep(ClaimStep.IDLE);
          }}
          onCompleteTransfer={handleCompleteTransfer}
        />
      )}
    </div>
  );
};

export default App;
