
import React, { useState, useEffect } from 'react';
import { LiveActivity } from '../types';

const ITEMS = ['Meowl', 'Strawberry Elephant', 'Lavadorito Spinito', 'La Grande Combinasion', 'Los 25', 'Ketupat Kepat'];

// Expanded variety of known diverse and active user IDs
const VARIETY_USER_IDS = [
  1, 16, 156, 2032622, 261, 80530, 25916, 31102146, 140130635, 17266733,
  23246233, 105319, 444555, 1092476, 2100698, 680454, 125432, 83042, 141444, 325123,
  123456, 999999, 555555, 111111, 222222, 333333, 444444, 777777, 888888, 101010,
  55030, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115
];

interface RealUserCore {
  username: string;
  displayName: string;
  avatarUrl: string;
}

const generateRandomRobloxName = () => {
  const prefixes = ['Elite', 'Mega', 'Super', 'Hyper', 'Crystal', 'Dark', 'Light', 'Shadow', 'Golden', 'Epic', 'Classic', 'Cool', 'Pro', 'Ultra', 'Swift', 'Mystic', 'Frost', 'Blaze', 'Storm'];
  const nouns = ['Gamer', 'Player', 'Slayer', 'Hunter', 'Warrior', 'Ninja', 'Master', 'Robloxian', 'King', 'Lord', 'Wolf', 'Dragon', 'Builder', 'Noob', 'Guest', 'Ace', 'Titan', 'Ghost'];
  const suffixes = ['', '_X', '123', '77', '00', '2024', 'YT', 'Plays', 'Pro', 'HD', '99', 'Real', 'Alt'];
  
  const p = prefixes[Math.floor(Math.random() * prefixes.length)];
  const n = nouns[Math.floor(Math.random() * nouns.length)];
  const s = suffixes[Math.floor(Math.random() * suffixes.length)];
  
  const joiner = Math.random() > 0.5 ? '_' : '';
  return `${p}${joiner}${n}${s}`;
};

const formatTimeAgo = (timestamp: number) => {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
};

const LiveActivityFeed: React.FC = () => {
  const [activities, setActivities] = useState<LiveActivity[]>([]);
  const [userPool, setUserPool] = useState<RealUserCore[]>([]);
  const [isReady, setIsReady] = useState(false);
  const [, setTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const fetchDiverseAvatars = async () => {
      try {
        const proxy = "https://corsproxy.io/?";
        
        // We fetch the thumbnails to ensure visual variety.
        const thumbRes = await fetch(`${proxy}${encodeURIComponent(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${VARIETY_USER_IDS.join(',')}&size=150x150&format=Png&isCircular=false`)}`);
        
        if (!thumbRes.ok) throw new Error("Thumbnail API failed");
        
        const thumbData = await thumbRes.json();

        if (!thumbData || !thumbData.data || thumbData.data.length === 0) {
          throw new Error("No thumbnail data returned");
        }

        // Map and filter out any failed thumbnails
        const pool: RealUserCore[] = thumbData.data
          .filter((thumb: any) => thumb.state === 'Completed' && thumb.imageUrl)
          .map((thumb: any) => {
            const randomName = generateRandomRobloxName();
            return {
              username: randomName,
              displayName: randomName,
              avatarUrl: thumb.imageUrl
            };
          });

        if (pool.length < 5) throw new Error("Pool too small after filtering");

        const shuffledPool = pool.sort(() => Math.random() - 0.5);
        setUserPool(shuffledPool);
        setIsReady(true);

        const initial = shuffledPool.slice(0, 6).map((user, i) => ({
          id: `init-${i}-${Date.now()}`,
          username: user.displayName,
          items: generateRandomItems(),
          timestamp: Date.now() - ([120, 600, 1500, 3600, 7200, 15000][i] * 1000),
          avatarUrl: user.avatarUrl
        }));
        setActivities(initial);
      } catch (err) {
        console.warn("Falling back to synthetic avatars due to:", err);
        // Fallback to high-variety synthetic avatars
        const avatarStyles = ['avataaars', 'pixel-art', 'bottts', 'adventurer', 'notionists'];
        const fallback = Array.from({ length: 25 }).map((_, i) => {
          const name = generateRandomRobloxName();
          const style = avatarStyles[i % avatarStyles.length];
          return {
            username: name,
            displayName: name,
            avatarUrl: `https://api.dicebear.com/7.x/${style}/svg?seed=${name}-${i}`
          };
        });
        setUserPool(fallback);
        setIsReady(true);
        
        const initial = fallback.slice(0, 6).map((user, i) => ({
          id: `init-fb-${i}-${Date.now()}`,
          username: user.displayName,
          items: generateRandomItems(),
          timestamp: Date.now() - ([120, 600, 1500, 3600, 7200, 15000][i] * 1000),
          avatarUrl: user.avatarUrl
        }));
        setActivities(initial);
      }
    };
    fetchDiverseAvatars();
  }, []);

  useEffect(() => {
    if (!isReady || userPool.length === 0) return;
    const interval = setInterval(() => {
      setActivities(prev => {
        const newUser = createActivity(userPool, `act-${Date.now()}`);
        // Ensure the new user isn't the same as the most recent one visually
        if (prev.length > 0 && prev[0].avatarUrl === newUser.avatarUrl) {
           return prev; // Skip this tick to maintain variety
        }
        return [newUser, ...prev.slice(0, 5)];
      });
    }, 5000 + Math.random() * 5000);
    return () => clearInterval(interval);
  }, [isReady, userPool]);

  function generateRandomItems() {
    const count = Math.floor(Math.random() * 2) + 1;
    const selected = [];
    const itemsCopy = [...ITEMS];
    for (let i = 0; i < count; i++) {
      const idx = Math.floor(Math.random() * itemsCopy.length);
      selected.push(itemsCopy.splice(idx, 1)[0]);
    }
    return selected;
  }

  function createActivity(pool: RealUserCore[], id: string): LiveActivity {
    // Pick a random user from the pool
    const user = pool[Math.floor(Math.random() * pool.length)];
    // Generate a fresh username for each "activity" to simulate new users joining
    const freshName = generateRandomRobloxName();
    return {
      id,
      username: freshName,
      items: generateRandomItems(),
      timestamp: Date.now(),
      avatarUrl: user.avatarUrl
    };
  }

  return (
    <div className="glass-card rounded-3xl p-6 overflow-hidden border border-white/10">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center border border-purple-500/30">
            <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
          </div>
          Live Claim Feed
        </h2>
        <div className="flex items-center gap-2 px-3 py-1 bg-red-500/15 rounded-full border border-red-500/30">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
          <span className="text-[10px] font-black text-red-500 tracking-widest uppercase">Verified Activity</span>
        </div>
      </div>

      {!isReady ? (
        <div className="space-y-4 animate-pulse">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-24 bg-white/5 rounded-2xl w-full border border-white/5" />
          ))}
        </div>
      ) : (
        <>
          <p className="text-gray-500 text-xs font-bold mb-6 px-1 flex items-center gap-2 uppercase tracking-tight">
            Monitoring <span className="text-purple-400 font-extrabold">Active Claims</span> across servers...
          </p>
          <div className="space-y-4">
            {activities.map((activity, idx) => (
              <div 
                key={activity.id} 
                className={`flex items-center gap-5 p-4 rounded-2xl transition-all duration-1000 animate-in slide-in-from-top-4 fade-in ${
                  idx === 0 
                    ? 'bg-purple-500/10 border-purple-500/30 shadow-[0_0_20px_rgba(168,85,247,0.15)] ring-1 ring-purple-500/20' 
                    : 'bg-white/[0.03] border-white/5'
                }`}
              >
                <div className="relative shrink-0">
                  <div className={`absolute -inset-1 rounded-full blur-sm transition-opacity duration-500 ${idx === 0 ? 'bg-purple-500/40 opacity-100' : 'opacity-0'}`} />
                  <img 
                    src={activity.avatarUrl} 
                    alt="User Avatar" 
                    className="relative w-14 h-14 rounded-full border-2 border-white/10 bg-[#12141a] object-cover shadow-2xl" 
                  />
                  <div className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full p-1 border-2 border-[#12141a]">
                    <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-extrabold text-sm tracking-tight flex items-center gap-1.5 truncate text-white">
                      {activity.username}
                      <svg className="w-4 h-4 text-blue-400 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" /></svg>
                    </span>
                    <span className="text-[10px] text-gray-500 font-black uppercase tracking-widest shrink-0 bg-white/5 px-2 py-0.5 rounded">
                      {formatTimeAgo(activity.timestamp)}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 font-semibold truncate leading-relaxed">
                    Successfully received <span className="text-purple-300 font-black">{activity.items.join(' + ')}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default LiveActivityFeed;
