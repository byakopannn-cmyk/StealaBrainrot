
import React from 'react';
import { BRAINROT_ITEMS } from '../constants';
import { BrainrotItem } from '../types';

interface Props {
  selectedItems: BrainrotItem[];
  onSelectItem: (item: BrainrotItem) => void;
  onClearSelection: () => void;
  onClaim: () => void;
  isAuth: boolean;
}

const RewardSelection: React.FC<Props> = ({ selectedItems, onSelectItem, onClearSelection, onClaim, isAuth }) => {
  return (
    <section className="space-y-6">
      <div className="flex flex-col gap-6">
        <div className="text-center sm:text-left">
          <h2 className="text-2xl md:text-3xl font-extrabold flex items-center justify-center sm:justify-start gap-3">
            Reward Selection
            <svg className="w-6 h-6 text-gray-600 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
          </h2>
          <p className="text-gray-400 mt-1 text-sm">Select up to <span className="text-purple-400 font-bold">3 items</span> to claim.</p>
        </div>

        <div className="flex flex-col xs:flex-row items-center gap-3 bg-[#1a1c23] p-3 rounded-2xl border border-white/5">
          <div className="px-4 text-center shrink-0 border-b xs:border-b-0 xs:border-r border-white/10 pb-2 xs:pb-0 xs:pr-4 w-full xs:w-auto">
            <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest">Cart</p>
            <p className="text-xl font-black leading-none mt-1">
              <span className={selectedItems.length > 0 ? "text-purple-400" : ""}>{selectedItems.length}</span>
              <span className="text-gray-600"> / 3</span>
            </p>
          </div>
          
          <div className="flex gap-2 w-full">
            <button 
              onClick={onClearSelection}
              disabled={selectedItems.length === 0}
              className="bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white px-4 py-3.5 rounded-xl font-bold text-xs transition-all disabled:opacity-0 disabled:pointer-events-none"
            >
              Clear
            </button>
            <button 
              onClick={onClaim}
              disabled={selectedItems.length === 0}
              className="flex-1 gradient-purple hover:brightness-110 active:scale-95 py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 shadow-xl shadow-purple-500/20 transition-all disabled:opacity-30 disabled:grayscale disabled:pointer-events-none"
            >
              Claim Items
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 md:gap-4">
        {BRAINROT_ITEMS.map((item) => {
          const isSelected = selectedItems.find(i => i.id === item.id);
          return (
            <div 
              key={item.id}
              onClick={() => onSelectItem(item)}
              className={`group relative glass-card rounded-2xl p-3 md:p-4 cursor-pointer transition-all duration-300 border-2 ${
                isSelected 
                  ? 'border-purple-500 shadow-[0_0_20px_rgba(168,85,247,0.2)] bg-purple-500/5' 
                  : 'border-white/5 hover:border-purple-500/40 hover:bg-white/[0.05]'
              }`}
            >
              <div className="relative aspect-square sm:aspect-[4/5] rounded-xl overflow-hidden mb-3 bg-black/40">
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className={`w-full h-full object-cover transition-transform duration-700 ${isSelected ? 'scale-110' : 'group-hover:scale-110'}`}
                />
                <div className={`absolute top-1.5 left-1.5 px-2 py-0.5 rounded-md text-[8px] md:text-[9px] font-black tracking-tighter ${
                  item.rarity === 'RADIOACTIVE' ? 'bg-emerald-500 text-black' : 
                  item.rarity === 'SECRET' ? 'bg-purple-600 text-white' : 'bg-amber-500 text-black'
                }`}>
                  {item.rarity}
                </div>
                
                {isSelected && (
                  <div className="absolute top-1.5 right-1.5 bg-purple-500 rounded-full p-1 shadow-lg animate-in zoom-in duration-300">
                    <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" /></svg>
                  </div>
                )}
              </div>

              <h3 className="font-bold text-center text-xs md:text-sm truncate px-1">{item.name}</h3>
              
              <button className={`w-full mt-2.5 py-2.5 rounded-lg text-[10px] font-black transition-all ${
                isSelected ? 'bg-purple-500 text-white' : 'bg-white/5 text-gray-500'
              }`}>
                {isSelected ? 'SELECTED' : 'SELECT'}
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default RewardSelection;
