
import React, { useState } from 'react';
import { RobloxUser } from '../types';

interface Props {
  onVerify: (user: RobloxUser) => void;
  authenticatedUser: RobloxUser | null;
  onReset: () => void;
}

const AuthSection: React.FC<Props> = ({ onVerify, authenticatedUser, onReset }) => {
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleVerify = async () => {
    if (!username.trim()) return;
    setIsLoading(true);
    setError(null);

    try {
      const proxy = "https://corsproxy.io/?";
      const cleanUsername = username.replace('@', '').trim();

      const userRes = await fetch(`${proxy}${encodeURIComponent(`https://users.roblox.com/v1/usernames/users`)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernames: [cleanUsername], excludeBannedUsers: true })
      });
      const userData = await userRes.json();

      if (!userData.data || userData.data.length === 0) {
        throw new Error("User not found. Check spelling.");
      }

      const { id: userId, displayName, name: robloxName } = userData.data[0];

      const [infoRes, thumbRes, friendsRes, followersRes, followingRes] = await Promise.all([
        fetch(`${proxy}${encodeURIComponent(`https://users.roblox.com/v1/users/${userId}`)}`),
        fetch(`${proxy}${encodeURIComponent(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=150x150&format=Png&isCircular=false`)}`),
        fetch(`${proxy}${encodeURIComponent(`https://friends.roblox.com/v1/users/${userId}/friends/count`)}`),
        fetch(`${proxy}${encodeURIComponent(`https://friends.roblox.com/v1/users/${userId}/followers/count`)}`),
        fetch(`${proxy}${encodeURIComponent(`https://friends.roblox.com/v1/users/${userId}/followings/count`)}`)
      ]);

      const [info, thumb, friends, followers, following] = await Promise.all([
        infoRes.json(),
        thumbRes.json(),
        friendsRes.json(),
        followersRes.json(),
        followingRes.json()
      ]);

      const avatarUrl = thumb.data?.[0]?.imageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanUsername}`;
      const createdDate = info.created ? new Date(info.created).toLocaleDateString() : 'Unknown';

      const realUser: RobloxUser = {
        username: `@${robloxName}`,
        displayName: displayName,
        userId: userId.toString(),
        avatarUrl: avatarUrl,
        joinedDate: createdDate,
        friends: friends.count || 0,
        followers: followers.count || 0,
        following: following.count || 0
      };

      onVerify(realUser);
    } catch (err: any) {
      setError(err.message || "Connection failed. Please try again.");
      console.error("Roblox API Error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  if (authenticatedUser) {
    return (
      <div className="glass-card rounded-2xl p-5 md:p-6 border border-emerald-500/20 bg-emerald-500/5 animate-in fade-in slide-in-from-bottom-4">
        <div className="flex flex-col sm:flex-row gap-5 md:gap-6">
          <div className="relative mx-auto sm:mx-0 shrink-0">
            <img 
              src={authenticatedUser.avatarUrl} 
              alt="Avatar" 
              className="w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-[#1f2937] bg-[#1f2937] shadow-xl object-cover"
            />
            <div className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full p-1.5 border-2 border-[#1f2937]">
              <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
            </div>
          </div>
          
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-3">
              <div className="text-center sm:text-left">
                <h3 className="text-lg md:text-xl font-bold flex items-center justify-center sm:justify-start gap-2">
                  {authenticatedUser.displayName}
                  <svg className="w-5 h-5 text-emerald-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                </h3>
                <p className="text-gray-400 font-medium text-sm">{authenticatedUser.username}</p>
              </div>
              <div className="flex gap-2 justify-center">
                <button 
                  onClick={() => window.open(`https://www.roblox.com/users/${authenticatedUser.userId}/profile`, '_blank')}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-xs font-bold transition-colors"
                >
                  View Profile
                </button>
                <button 
                  onClick={onReset}
                  className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-bold transition-colors"
                >
                  Change
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-4">
              <Stat label="ID" value={authenticatedUser.userId} />
              <Stat label="JOINED" value={authenticatedUser.joinedDate} />
              <Stat label="FRIENDS" value={authenticatedUser.friends} />
              <Stat label="FOLLOWS" value={authenticatedUser.followers} />
            </div>
          </div>
        </div>
        
        <div className="mt-4 flex items-start gap-2 text-emerald-400 text-[10px] md:text-xs font-bold bg-emerald-400/10 px-4 py-3 rounded-lg border border-emerald-400/20">
          <svg className="w-4 h-4 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
          <span className="leading-tight">Established secure session for {authenticatedUser.displayName}. Profile verified.</span>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card rounded-2xl p-5 md:p-8">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl gradient-purple flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0">
          <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
        </div>
        <div>
          <h2 className="text-lg md:text-xl font-bold">Roblox Authentication</h2>
          <p className="text-gray-400 text-xs md:text-sm">Real-time profile lookup required</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <input 
            type="text" 
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
            placeholder="Roblox username"
            className="flex-1 bg-[#1a1c23] border border-white/10 rounded-xl px-4 py-4 focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all font-medium text-base h-14 md:h-16"
          />
          <button 
            onClick={handleVerify}
            disabled={isLoading || !username}
            className="gradient-purple hover:brightness-110 active:scale-95 h-14 md:h-16 rounded-xl font-bold text-lg shadow-xl shadow-purple-500/20 transition-all disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center sm:px-10"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Verifying...</span>
              </div>
            ) : 'Verify Profile'}
          </button>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-start gap-3 animate-in slide-in-from-top-2">
            <svg className="w-5 h-5 text-red-500 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <p className="text-red-400 text-sm font-bold leading-tight">{error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

const Stat = ({ label, value }: { label: string; value: string | number }) => (
  <div className="bg-white/5 p-2.5 md:p-3 rounded-xl border border-white/5">
    <p className="text-[9px] md:text-[10px] font-black text-gray-500 mb-1 tracking-tighter uppercase">{label}</p>
    <p className="text-xs md:text-sm font-bold tracking-tight text-gray-200 truncate">{value}</p>
  </div>
);

export default AuthSection;
