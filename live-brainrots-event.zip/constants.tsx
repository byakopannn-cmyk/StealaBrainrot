
import { BrainrotItem } from './types';

/**
 * EDIT THESE IMAGE URLS TO CHANGE THE BRAINROT IMAGES
 * All URLs have been updated per user requirements.
 */
const IMAGES = {
  MEOWL: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9UzalN4nrKRmSoO3uSWSupXb6OlWwmY1qRbe4zpYAfg&s',
  STRAWBERRY_ELEPHANT: 'https://static.wikia.nocookie.net/stealabr/images/5/58/Radioactive_og.png/revision/latest/scale-to-width-down/250?cb=20251122121444',
  LAVADORITO: 'https://static.wikia.nocookie.net/stealabr/images/f/ff/Lavadorito_Spinito.png/revision/latest?cb=20251123122422',
  GRANDE_COMBINASION: 'https://static.wikia.nocookie.net/stealabr/images/d/d8/Carti.png/revision/latest?cb=20250909171004',
  LOS_25: 'https://static.wikia.nocookie.net/stealabr/images/5/5c/Rework.png/revision/latest?cb=20251207004831',
  KETUPAT: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ03842yr2C_z40VSp708hSabg8cN0GdyGBtA&s'
};

export const BRAINROT_ITEMS: BrainrotItem[] = [
  {
    id: '1',
    name: 'Meowl',
    rarity: 'RADIOACTIVE',
    image: IMAGES.MEOWL
  },
  {
    id: '2',
    name: 'Strawberry Elephant',
    rarity: 'RADIOACTIVE',
    image: IMAGES.STRAWBERRY_ELEPHANT
  },
  {
    id: '3',
    name: 'Lavadorito Spinito',
    rarity: 'SECRET',
    image: IMAGES.LAVADORITO
  },
  {
    id: '4',
    name: 'La Grande Combinasion',
    rarity: 'SECRET',
    image: IMAGES.GRANDE_COMBINASION
  },
  {
    id: '5',
    name: 'Los 25',
    rarity: 'SECRET',
    image: IMAGES.LOS_25
  },
  {
    id: '6',
    name: 'Ketupat Kepat',
    rarity: 'SECRET',
    image: IMAGES.KETUPAT
  }
];

export const SERVER_LINK = 'https://roblox.com.ge/games/109983668079237/Steal-a-Brainrot?privateServerLinkCode=63776496008489733878933289493190';
